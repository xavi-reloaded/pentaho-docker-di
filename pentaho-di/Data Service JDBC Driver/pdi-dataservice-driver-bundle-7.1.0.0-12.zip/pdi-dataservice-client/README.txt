The pdi-dataservice-client zip contains all of the jar files required to make a JDBC connection to a running Data Service.

Configuration documentation can be found at https://help.pentaho.com/Documentation/7.0/0L0/0Y0/090/040
